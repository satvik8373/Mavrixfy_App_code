import React, { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Heart, Music, Play, Pause, Clock, MoreHorizontal, ArrowDownUp, Search, Plus, ListPlus, User, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ShuffleButton } from '@/components/ShuffleButton';
import { Input } from '@/components/ui/input';
import { usePlayerStore } from '@/stores/usePlayerStore';
import { usePlayerSync } from '@/hooks/usePlayerSync';
import { useAuthStore } from '@/stores/useAuthStore';
import { useLikedSongsStore } from '@/stores/useLikedSongsStore';
import { Song } from '@/types';
import toast from 'react-hot-toast';
import { cn } from '@/lib/utils';
import { useSpotify } from '@/contexts/SpotifyContext';
import './liked-songs.css';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { LikeButton } from '@/components/LikeButton';

// Format time
const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
};

// Memoized song item component to prevent unnecessary re-renders
const MemoizedSongItem = React.memo(({
  song,
  index,
  isMobile,
  isSongPlaying,
  onPlay,
  onTogglePlay,
  onAddToQueue,
  onUnlike
}: {
  song: Song;
  index: number;
  isMobile: boolean;
  isSongPlaying: boolean;
  onPlay: () => void;
  onTogglePlay: () => void;
  onAddToQueue: () => void;
  onUnlike: () => void;
}) => {
  // Use CSS transforms instead of layout changes to prevent reflows
  const itemStyle = {
    transform: 'translateZ(0)', // Force hardware acceleration
    willChange: 'auto' // Let browser optimize
  };

  return (
    <div
      onClick={onPlay}
      style={itemStyle}
      className={cn(
        "group relative rounded-md cursor-pointer items-center",
        isMobile
          ? "flex gap-3 p-3 py-2 active:bg-muted/30"
          : "grid grid-cols-[16px_4fr_3fr_2fr_40px_1fr_48px] gap-4 p-2 px-4 hover:bg-muted/50 transition-colors"
      )}
    >
      {/* Desktop Index/Play button */}
      {!isMobile && (
        <div className="flex items-center justify-center text-sm text-muted-foreground group-hover:text-foreground">
          {isSongPlaying ? (
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 text-primary hover:text-primary/80"
              onClick={(e) => {
                e.stopPropagation();
                onTogglePlay();
              }}
            >
              <Pause className="h-4 w-4 fill-current" />
            </Button>
          ) : (
            <>
              <span className="group-hover:hidden">{index + 1}</span>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 hidden group-hover:flex"
                onClick={(e) => {
                  e.stopPropagation();
                  onPlay();
                }}
              >
                <Play className="h-4 w-4 fill-current" />
              </Button>
            </>
          )}
        </div>
      )}

      {/* Song info - Spotify-style with better album artwork */}
      <div className="flex items-center min-w-0 flex-1">
        <div className={cn(
          "flex-shrink-0 overflow-hidden rounded shadow-md relative",
          isMobile ? "w-14 h-14 mr-3" : "w-12 h-12 mr-3"
        )}>
          <img
            src={song.imageUrl || '/placeholder-song.jpg'}
            alt={song.title}
            className="w-full h-full object-cover"
            loading="lazy"
            decoding="async"
            style={{ 
              contentVisibility: 'auto',
              containIntrinsicSize: isMobile ? '56px 56px' : '48px 48px'
            }}
            onError={(e) => {
              (e.currentTarget as HTMLImageElement).src = '/placeholder-song.jpg';
            }}
          />
        </div>
        <div className="min-w-0 flex-1">
          <div className={cn(
            "font-medium text-base",
            isSongPlaying ? "text-green-500" : "text-foreground",
            isMobile ? "leading-tight" : "truncate"
          )}>
            {song.title}
          </div>
          <div className={cn(
            "text-muted-foreground text-sm truncate whitespace-nowrap overflow-hidden",
            isMobile ? "leading-tight" : ""
          )}>
            {song.artist}
          </div>
        </div>
      </div>

      {/* Mobile actions - positioned on the right */}
      {isMobile && (
        <div className="flex-shrink-0 flex items-center gap-2">
          <LikeButton
            isLiked={true}
            onToggle={(e) => {
              e.stopPropagation();
              onUnlike();
            }}
            iconSize={24}
            className="mr-1"
          />
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 opacity-60 group-hover:opacity-100 transition-opacity"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" side="bottom">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToQueue();
                }}
              >
                <ListPlus className="h-4 w-4 mr-2" />
                Add to Queue
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onUnlike();
                }}
                className="text-red-400"
              >
                <Heart className="h-4 w-4 mr-2" />
                Remove from Liked Songs
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}

      {/* Desktop album */}
      {!isMobile && (
        <div className="flex items-center text-muted-foreground truncate">
          {song.albumId || 'Unknown Album'}
        </div>
      )}

      {/* Desktop date added */}
      {!isMobile && (
        <div className="flex items-center text-muted-foreground text-sm">
          {song.likedAt ?
            new Date(song.likedAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: new Date().getFullYear() !== new Date(song.likedAt).getFullYear() ? 'numeric' : undefined
            }) :
            new Date(song.createdAt).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: new Date().getFullYear() !== new Date(song.createdAt).getFullYear() ? 'numeric' : undefined
            })
          }
        </div>
      )}

      {/* Desktop Like Button */}
      {!isMobile && (
        <div className="flex items-center justify-center">
          <LikeButton
            isLiked={true}
            onToggle={(e) => {
              e.stopPropagation();
              onUnlike();
            }}
            iconSize={20}
          />
        </div>
      )}

      {/* Duration */}
      {!isMobile && (
        <div className="flex items-center text-muted-foreground text-sm justify-end">
          {formatTime(song.duration || 0)}
        </div>
      )}

      {/* Desktop actions - simple dropdown */}
      {!isMobile && (
        <div className="flex justify-end">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
                onClick={(e) => e.stopPropagation()}
              >
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" side="bottom">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onAddToQueue();
                }}
              >
                <ListPlus className="h-4 w-4 mr-2" />
                Add to Queue
              </DropdownMenuItem>
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  onUnlike();
                }}
                className="text-red-400"
              >
                <Heart className="h-4 w-4 mr-2" />
                Remove from Liked Songs
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      )}
    </div>
  );
}, (prevProps, nextProps) => {
  // More stable comparison to prevent excessive re-renders
  const prevId = prevProps.song._id;
  const nextId = nextProps.song._id;

  // Only re-render if the song ID changed or playing state changed
  // Don't check other props to reduce sensitivity to changes
  return (
    prevId === nextId &&
    prevProps.isSongPlaying === nextProps.isSongPlaying
  );
});

MemoizedSongItem.displayName = 'MemoizedSongItem';

const LikedSongsPage = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isMobile, setIsMobile] = useState(window.innerWidth < 768);
  const [sortMethod, setSortMethod] = useState<'recent' | 'title' | 'artist'>('recent');
  const [filterQuery, setFilterQuery] = useState('');

  const navigate = useNavigate();

  const { togglePlay, playAlbum, setIsPlaying, setUserInteracted } = usePlayerStore();
  const { currentSong, isPlaying } = usePlayerSync();
  const { isAuthenticated } = useAuthStore();
  const { isAuthenticated: isSpotifyConnected, fetchSavedTracks } = useSpotify();

  // Use the store instead of local state for liked songs
  const { likedSongs, loadLikedSongs: loadLikedSongsFromStore, removeLikedSong: removeLikedSongFromStore } = useLikedSongsStore();

  // Force re-render when liked songs change
  const [, forceUpdate] = useState({});

  // Subscribe to store changes to force re-renders
  useEffect(() => {
    // Use a simpler approach - just subscribe to the store directly
    const unsubscribe = useLikedSongsStore.subscribe(() => {
      // Force re-render when the store state changes
      forceUpdate({});
    });

    return unsubscribe;
  }, []);

  // Load liked songs on mount
  useEffect(() => {
    loadAndSetLikedSongs();
  }, [isAuthenticated]);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const loadAndSetLikedSongs = async () => {
    if (!isAuthenticated) {
      return;
    }

    try {
      // Use the store method instead of direct service call
      await loadLikedSongsFromStore();
    } catch (error) {
      // Error loading liked songs
      toast.error('Failed to load liked songs');
    }
  };

  // Optimized sort function with memoization
  const sortSongs = useCallback((songs: Song[], method: 'recent' | 'title' | 'artist') => {
    if (!songs || songs.length === 0) return [];

    // Use a more efficient sorting approach
    switch (method) {
      case 'recent':
        // Sort by likedAt timestamp (most recent first)
        return [...songs].sort((a, b) => {
          const aDate = a.likedAt ? new Date(a.likedAt).getTime() : new Date(a.createdAt).getTime();
          const bDate = b.likedAt ? new Date(b.likedAt).getTime() : new Date(b.createdAt).getTime();
          return bDate - aDate; // Descending order (newest first)
        });
      case 'title':
        return [...songs].sort((a, b) => a.title.localeCompare(b.title));
      case 'artist':
        return [...songs].sort((a, b) => a.artist.localeCompare(b.artist));
      default:
        return songs;
    }
  }, []);

  // Optimized filtered and sorted songs with better memoization
  const visibleSongs = useMemo(() => {
    if (!likedSongs.length) return [];

    const q = filterQuery.trim().toLowerCase();
    let filtered = likedSongs;

    // Only filter if there's a query to avoid unnecessary work
    if (q) {
      filtered = likedSongs.filter((s) =>
        `${s.title} ${s.artist}`.toLowerCase().includes(q)
      );
    }

    return sortSongs(filtered, sortMethod);
  }, [likedSongs, filterQuery, sortMethod, sortSongs]);

  // Define isSongPlaying first since it's used by other functions
  const isSongPlaying = useCallback((song: Song) => {
    if (!isPlaying || !currentSong) return false;

    // Get primary IDs for comparison - be more strict about ID matching
    const currentSongId = currentSong._id;
    const songId = song._id;

    // Only return true if we have valid IDs and they match exactly
    if (currentSongId && songId) {
      return currentSongId === songId;
    }

    // If no IDs available, fall back to exact title and artist match
    // But be very strict to avoid false positives
    if (currentSong.title && song.title && currentSong.artist && song.artist) {
      return (
        currentSong.title.trim().toLowerCase() === song.title.trim().toLowerCase() &&
        currentSong.artist.trim().toLowerCase() === song.artist.trim().toLowerCase()
      );
    }

    return false;
  }, [isPlaying, currentSong]);

  // Memoized callbacks to prevent child re-renders
  const handlePlaySong = useCallback((song: Song, index: number) => {
    // Use the same comparison logic as isSongPlaying
    if (currentSong && isSongPlaying(song)) {
      togglePlay();
      return;
    }

    playAlbum(visibleSongs, index);
    // Remove setTimeout to prevent performance violations
    setIsPlaying(true);
    setUserInteracted();
  }, [currentSong, togglePlay, playAlbum, visibleSongs, setIsPlaying, setUserInteracted, isSongPlaying]);

  const handleAddToQueue = useCallback((song: Song) => {
    const { addToQueue: addSongToQueue } = usePlayerStore.getState();
    addSongToQueue(song);
    toast.success(`Added "${song.title}" to queue`, {
      duration: 2000,
    });
  }, []);

  const handleUnlikeSong = useCallback(async (songId: string) => {
    if (!songId || songId === 'undefined' || songId === 'null') {
      toast.error('Cannot remove song: Invalid ID');
      return;
    }
    
    try {
      // Use the store method instead of direct service call
      await removeLikedSongFromStore(songId);
      toast.success('Removed from Liked Songs');
    } catch (error) {
      toast.error('Failed to remove song');
    }
  }, [removeLikedSongFromStore]);

  // Update sort method and re-sort songs
  const handleSortChange = useCallback((method: 'recent' | 'title' | 'artist') => {
    setSortMethod(method);
  }, []);

  // Play all liked songs
  const playAllSongs = useCallback(() => {
    if (likedSongs.length > 0) {
      playAlbum(likedSongs, 0);
      // Remove setTimeout to prevent performance violations
      setIsPlaying(true);
      setUserInteracted();
    }
  }, [likedSongs, playAlbum, setIsPlaying, setUserInteracted]);

  // Check if the current liked songs playlist is playing
  const isCurrentPlaylistPlaying = useMemo(() => {
    if (!isPlaying || !currentSong || likedSongs.length === 0) return false;
    
    // Check if the current song is in the liked songs list
    return likedSongs.some(song => {
      const currentSongId = currentSong._id;
      const songId = song._id;
      
      if (currentSongId && songId) {
        return currentSongId === songId;
      }
      
      // Fallback to title and artist match
      return (
        currentSong.title?.trim().toLowerCase() === song.title?.trim().toLowerCase() &&
        currentSong.artist?.trim().toLowerCase() === song.artist?.trim().toLowerCase()
      );
    });
  }, [isPlaying, currentSong, likedSongs]);

  // Handle pause playlist functionality
  const handlePausePlaylist = useCallback(() => {
    if (isPlaying) {
      setIsPlaying(false);
    }
  }, [isPlaying, setIsPlaying]);

  // Handle main play/pause button
  const handleMainPlayPause = useCallback(() => {
    if (isCurrentPlaylistPlaying) {
      handlePausePlaylist();
    } else {
      playAllSongs();
    }
  }, [isCurrentPlaylistPlaying, handlePausePlaylist, playAllSongs]);

  // Manual Spotify sync
  const handleManualSync = useCallback(async () => {
    if (!isSpotifyConnected) {
      toast.error('Please connect to Spotify first');
      return;
    }

    try {
      setIsLoading(true);
      toast.loading('Syncing with Spotify...', { id: 'manual-sync' });

      // Fetch saved tracks from Spotify
      const spotifyTracks = await fetchSavedTracks(50); // Get recent 50 tracks

      if (spotifyTracks.length === 0) {
        toast.success('No new tracks to sync', { id: 'manual-sync' });
        return;
      }

      // Process and add tracks (this would use the existing SpotifyLikedSongsSync logic)
      // For now, just show success message
      toast.success(`Found ${spotifyTracks.length} tracks from Spotify!`, { id: 'manual-sync' });

      toast.success(`Found ${spotifyTracks.length} tracks from Spotify!`, { id: 'manual-sync' });

      // Navigate to the sync page with spotify tab active
      navigate('/liked-songs/sync');

    } catch (error) {
      // Manual sync error
      toast.error('Failed to sync with Spotify', { id: 'manual-sync' });
    } finally {
      setIsLoading(false);
    }
  }, [isSpotifyConnected, fetchSavedTracks]);

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center">
        <Heart className="h-16 w-16 text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Sign in to see your liked songs</h2>
        <p className="text-muted-foreground">Create an account to save your favorite music</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground liked-songs-page">
      {/* Mobile Header */}
      {isMobile ? (
        <div className="relative">
          {/* Mobile gradient header - Spotify-like */}
          <div className="bg-gradient-to-b from-purple-600/80 via-purple-700/60 to-background px-4 pt-16 pb-6">
            <div className="flex items-center gap-4">
              {/* Spotify-style heart icon for mobile */}
              <div className="w-20 h-20 bg-gradient-to-br from-purple-400 via-purple-500 to-purple-600 rounded-md flex items-center justify-center shadow-2xl relative overflow-hidden flex-shrink-0">
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 via-transparent to-black/30"></div>
                <Heart className="h-10 w-10 text-white fill-white relative z-10 drop-shadow-lg" />
                <div className="absolute top-2 left-2 w-6 h-6 bg-white/30 rounded-full blur-md"></div>
              </div>

              {/* Mobile title section - Spotify style */}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white/80 mb-1">Playlist</p>
                <h1 className="text-3xl font-bold text-white drop-shadow-sm mb-2 leading-tight">Liked Songs</h1>
                <div className="flex items-center gap-1 text-sm text-white/70">
                  <User className="h-4 w-4" />
                  <span>Satvik patel • {likedSongs.length} songs</span>
                </div>
              </div>
            </div>
          </div>

          {/* Mobile controls - Spotify-style */}
          <div className="px-4 pb-4 flex items-center justify-between bg-gradient-to-b from-background/20 to-background">
            <div className="flex items-center gap-4">
              <Button
                size="icon"
                className="h-14 w-14 rounded-full bg-green-500 hover:bg-green-400 shadow-xl hover:shadow-2xl transition-all duration-200 hover:scale-105"
                onClick={handleMainPlayPause}
                disabled={likedSongs.length === 0}
              >
                {isCurrentPlaylistPlaying ? (
                  <Pause className="h-6 w-6 fill-current text-black" />
                ) : (
                  <Play className="h-6 w-6 fill-current ml-0.5 text-black" />
                )}
              </Button>

              <ShuffleButton
                size="md"
                className="h-10 w-10 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                accentColor="#1ed760"
              />

              <Button
                variant="ghost"
                size="icon"
                className="h-10 w-10 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                onClick={() => {
                  navigate('/liked-songs/sync');
                }}
              >
                <Plus className="h-5 w-5" />
              </Button>

              {isSpotifyConnected && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                  onClick={handleManualSync}
                  disabled={isLoading}
                  title="Sync with Spotify"
                >
                  <RefreshCw className={cn("h-5 w-5", isLoading && "animate-spin")} />
                </Button>
              )}
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-10 w-10 text-white/70 hover:text-white hover:bg-white/10">
                  <MoreHorizontal className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => handleSortChange('recent')}>
                  <Clock className="h-4 w-4 mr-2" />
                  Recently Added
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSortChange('title')}>
                  <ArrowDownUp className="h-4 w-4 mr-2" />
                  Title
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => handleSortChange('artist')}>
                  <Music className="h-4 w-4 mr-2" />
                  Artist
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      ) : (
        /* Desktop Header - Spotify-style */
        <div className="relative">
          <div className="bg-gradient-to-b from-purple-600/60 via-purple-700/40 to-background p-8 pb-6">
            <div className="flex items-end gap-6">
              <div className="w-56 h-56 bg-gradient-to-br from-purple-400 via-purple-500 to-purple-600 rounded-md flex items-center justify-center shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-white/15 via-transparent to-black/25"></div>
                <Heart className="h-24 w-24 text-white fill-white relative z-10 drop-shadow-lg" />
                <div className="absolute top-6 left-6 w-20 h-20 bg-white/25 rounded-full blur-xl"></div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-white/90 mb-3">Playlist</p>
                <h1 className="text-5xl md:text-7xl font-black mb-6 text-white drop-shadow-sm tracking-tight">Liked Songs</h1>
                <div className="flex items-center gap-2 text-sm text-white/80">
                  <User className="h-4 w-4" />
                  <span className="font-medium">Satvik patel</span>
                  <span>•</span>
                  <span>{likedSongs.length} songs</span>
                </div>
              </div>
            </div>
          </div>

          <div className="px-8 pb-6 flex items-center justify-between bg-gradient-to-b from-background/20 to-background">
            <div className="flex items-center gap-6">
              <Button
                size="icon"
                className="h-16 w-16 rounded-full bg-green-500 hover:bg-green-400 shadow-xl hover:shadow-2xl transition-all duration-200 hover:scale-105"
                onClick={handleMainPlayPause}
                disabled={likedSongs.length === 0}
              >
                {isCurrentPlaylistPlaying ? (
                  <Pause className="h-7 w-7 fill-current text-black" />
                ) : (
                  <Play className="h-7 w-7 fill-current ml-0.5 text-black" />
                )}
              </Button>

              <ShuffleButton
                size="lg"
                className="h-12 w-12 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                accentColor="#1ed760"
              />

              <Button
                variant="ghost"
                size="icon"
                className="h-12 w-12 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                onClick={() => {
                  navigate('/liked-songs/sync');
                }}
              >
                <Plus className="h-6 w-6" />
              </Button>

              {isSpotifyConnected && (
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-12 w-12 text-white/80 hover:text-white hover:bg-white/10 hover:scale-105 transition-all duration-200"
                  onClick={handleManualSync}
                  disabled={isLoading}
                  title="Sync with Spotify"
                >
                  <RefreshCw className={cn("h-6 w-6", isLoading && "animate-spin")} />
                </Button>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-12 w-12 text-white/70 hover:text-white hover:bg-white/10">
                    <MoreHorizontal className="h-6 w-6" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start">
                  <DropdownMenuItem onClick={() => handleSortChange('recent')}>
                    <Clock className="h-4 w-4 mr-2" />
                    Recently Added
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleSortChange('title')}>
                    <ArrowDownUp className="h-4 w-4 mr-2" />
                    Title
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleSortChange('artist')}>
                    <Music className="h-4 w-4 mr-2" />
                    Artist
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      )}

      {/* Search - Spotify-style */}
      {likedSongs.length > 0 && (
        <div className={cn("pb-4", isMobile ? "px-4" : "px-8")}>
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground/70" />
            <Input
              placeholder="Search in liked songs"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              className={cn(
                "pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/60 focus:bg-white/15 focus:border-white/30 transition-all duration-200",
                isMobile ? "h-10 text-sm" : "h-11"
              )}
            />
          </div>
        </div>
      )}

      {/* Songs List - Spotify-style */}
      <div className={cn(isMobile ? "px-4 pb-32" : "px-8 pb-8")}>
        {isLoading ? (
          <div className="py-12"></div>
        ) : likedSongs.length > 0 ? (
          <div className={cn("pb-8", isMobile ? "pb-32" : "")}>
            {/* Desktop header */}
            {!isMobile && (
              <div className="grid grid-cols-[16px_4fr_3fr_2fr_40px_1fr_48px] gap-4 px-4 py-2 text-sm text-muted-foreground border-b mb-2">
                <div>#</div>
                <div>Title</div>
                <div>Album</div>
                <div>Date added</div>
                <div></div>
                <div><Clock className="h-4 w-4" /></div>
                <div></div>
              </div>
            )}

            {visibleSongs.map((song, index) => {
              // Create a unique key using the Firestore document ID
              const uniqueKey = song._id || `${song.title}-${song.artist}-${index}`;

              return (
                <MemoizedSongItem
                  key={uniqueKey}
                  song={song}
                  index={index}
                  isMobile={isMobile}
                  isSongPlaying={isSongPlaying(song)}
                  onPlay={() => handlePlaySong(song, index)}
                  onTogglePlay={togglePlay}
                  onAddToQueue={() => handleAddToQueue(song)}
                  onUnlike={() => {
                    const songId = song._id;
                    if (songId) {
                      handleUnlikeSong(songId);
                    } else {
                      toast.error('Cannot remove song: No valid ID found');
                    }
                  }}
                />
              );
            })}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Heart className="h-16 w-16 text-muted-foreground mb-4" />
            <h3 className="text-xl font-semibold mb-2">No liked songs yet</h3>
            <p className="text-muted-foreground mb-6">Songs you like will appear here</p>
            <Button onClick={() => {
              navigate('/liked-songs/sync');
            }}>
              <Plus className="h-4 w-4 mr-2" />
              Add Songs
            </Button>
          </div>
        )}
      </div>

      {/* Add Songs Dialog removed - replaced with /liked-songs/sync page */}
    </div>
  );
};

export default LikedSongsPage;