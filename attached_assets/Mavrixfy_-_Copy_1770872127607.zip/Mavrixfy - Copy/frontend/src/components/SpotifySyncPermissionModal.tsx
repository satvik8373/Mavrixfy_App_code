import React, { useState, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Music, Clock, Heart, Check, X, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { cn } from '@/lib/utils';

interface SpotifyTrack {
  id: string;
  title: string;
  artist: string;
  album: string;
  imageUrl: string;
  duration: number;
  addedAt: string;
}

interface SpotifySyncPermissionModalProps {
  isOpen: boolean;
  onClose: () => void;
  tracks: SpotifyTrack[];
  onSync: (selectedTrackIds: string[]) => void;
  isLoading?: boolean;
}

const SpotifySyncPermissionModal: React.FC<SpotifySyncPermissionModalProps> = ({
  isOpen,
  onClose,
  tracks,
  onSync,
  isLoading = false
}) => {
  const [selectedTracks, setSelectedTracks] = useState<Set<string>>(new Set());
  const [selectAll, setSelectAll] = useState(true);
  const [filter, setFilter] = useState('');

  // Defensive: ensure we always work with an array
  const safeTracks: SpotifyTrack[] = useMemo(() => (Array.isArray(tracks) ? tracks : []), [tracks]);

  // Filter tracks based on search
  const filteredTracks = useMemo(() => {
    if (!filter.trim()) return safeTracks;
    const searchTerm = filter.toLowerCase();
    return safeTracks.filter(track => 
      track.title.toLowerCase().includes(searchTerm) ||
      track.artist.toLowerCase().includes(searchTerm) ||
      track.album.toLowerCase().includes(searchTerm)
    );
  }, [safeTracks, filter]);

  // Initialize with all tracks selected by default
  useEffect(() => {
    if (safeTracks.length > 0) {
      setSelectedTracks(new Set(safeTracks.map(track => track.id)));
      setSelectAll(true);
    } else {
      setSelectedTracks(new Set());
      setSelectAll(false);
    }
  }, [safeTracks]);

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedTracks(new Set());
      setSelectAll(false);
    } else {
      setSelectedTracks(new Set(filteredTracks.map(track => track.id)));
      setSelectAll(true);
    }
  };

  const handleTrackToggle = (trackId: string) => {
    const newSelected = new Set(selectedTracks);
    if (newSelected.has(trackId)) {
      newSelected.delete(trackId);
    } else {
      newSelected.add(trackId);
    }
    setSelectedTracks(newSelected);
    setSelectAll(newSelected.size === filteredTracks.length);
  };

  const handleSync = () => {
    onSync(Array.from(selectedTracks));
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return 'Today';
    if (diffDays === 2) return 'Yesterday';
    if (diffDays <= 7) return `${diffDays} days ago`;
    if (diffDays <= 30) return `${Math.ceil(diffDays / 7)} weeks ago`;
    return date.toLocaleDateString();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className={cn(
        "w-[95vw] max-w-2xl h-[85vh] max-h-[700px] p-0",
        "sm:w-[90vw] sm:h-[80vh]",
        "flex flex-col overflow-hidden"
      )}>
        {/* Header */}
        <div className="flex-shrink-0 p-4 sm:p-6 border-b border-border/50">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-green-500/10 rounded-full flex items-center justify-center">
                <Heart className="h-5 w-5 text-green-500" />
              </div>
              <div>
                <h3 className="text-lg sm:text-xl font-semibold text-foreground">
                  New Spotify Songs
                </h3>
                <p className="text-sm text-muted-foreground">
                  Recently added to your Spotify liked songs
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="h-8 w-8 rounded-full"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {/* Search and Stats */}
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search new songs..."
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="pl-10 h-10"
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-xs">
                  {filteredTracks.length} new songs
                </Badge>
                <Badge variant="outline" className="text-xs">
                  {selectedTracks.size} selected
                </Badge>
              </div>
              
              <Button
                variant="ghost"
                size="sm"
                onClick={handleSelectAll}
                className="text-xs h-8"
              >
                {selectAll ? 'Deselect All' : 'Select All'}
              </Button>
            </div>
          </div>
        </div>

        {/* Track List */}
        <ScrollArea className="flex-1 px-2">
          <div className="space-y-1 p-2">
            {filteredTracks.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Music className="h-12 w-12 text-muted-foreground/50 mb-4" />
                <p className="text-muted-foreground">
                  {filter ? 'No songs match your search' : 'No new songs found'}
                </p>
              </div>
            ) : (
              filteredTracks.map((track) => (
                <div
                  key={track.id}
                  onClick={() => handleTrackToggle(track.id)}
                  className={cn(
                    "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-all duration-200",
                    "hover:bg-accent/50 active:bg-accent/70",
                    selectedTracks.has(track.id) 
                      ? "bg-accent/30 border border-primary/20" 
                      : "hover:bg-muted/30"
                  )}
                >
                  {/* Checkbox */}
                  <div className={cn(
                    "w-5 h-5 rounded border-2 flex items-center justify-center transition-all",
                    selectedTracks.has(track.id)
                      ? "bg-primary border-primary"
                      : "border-muted-foreground/30 hover:border-primary/50"
                  )}>
                    {selectedTracks.has(track.id) && (
                      <Check className="h-3 w-3 text-primary-foreground" />
                    )}
                  </div>

                  {/* Album Art */}
                  <div className="w-12 h-12 rounded-md overflow-hidden bg-muted flex-shrink-0">
                    {track.imageUrl ? (
                      <img 
                        src={track.imageUrl} 
                        alt={track.album}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Music className="h-5 w-5 text-muted-foreground" />
                      </div>
                    )}
                  </div>

                  {/* Track Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-sm text-foreground truncate">
                      {track.title}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">
                      {track.artist}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs px-1.5 py-0.5">
                        {formatDate(track.addedAt)}
                      </Badge>
                      <span className="text-xs text-muted-foreground/70 hidden sm:inline">
                        {formatTime(track.duration)}
                      </span>
                    </div>
                  </div>

                  {/* Duration - Mobile */}
                  <div className="sm:hidden text-xs text-muted-foreground flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {formatTime(track.duration)}
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="flex-shrink-0 p-4 sm:p-6 border-t border-border/50">
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1 sm:flex-none"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSync}
              disabled={selectedTracks.size === 0 || isLoading}
              className="flex-1 sm:flex-none"
            >
              {isLoading ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin mr-2" />
                  Syncing...
                </>
              ) : (
                <>
                  <Heart className="h-4 w-4 mr-2" />
                  Add {selectedTracks.size} Songs
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] max-w-[95vw] sm:max-w-[600px] md:max-w-[800px] lg:max-w-[900px] h-[90vh] max-h-[90vh] p-0 flex flex-col overflow-hidden bg-background border">
        {/* Header - Fixed */}
        <DialogHeader className="px-4 pt-4 pb-2 flex-shrink-0 bg-background border-b">
          <DialogTitle className="flex items-center justify-between">
            <span className="inline-flex items-center gap-2">
              <Music className="h-5 w-5 text-green-500" />
              <span className="text-base sm:text-lg font-semibold text-foreground">Sync New Spotify Songs</span>
            </span>
            <span className="inline-flex items-center gap-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 bg-muted border">
                <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
                {safeTracks.length} new
              </span>
              <span className="hidden sm:inline">•</span>
              <span className="hidden sm:inline">{selectedTracks.size} selected</span>
            </span>
          </DialogTitle>
        </DialogHeader>

        {/* Content - Scrollable */}
        <div className="flex-1 min-h-0 flex flex-col">
          {/* Summary Section - Compact */}
          <div className="px-4 pt-2 pb-2 flex-shrink-0">
            <div className="flex items-center justify-between gap-2 p-2">
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-foreground">Found {safeTracks.length} new songs from Spotify</p>
                <p className="text-xs text-muted-foreground mt-0.5">Select which new songs to add to Mavrixfy</p>
              </div>
              <div className="flex items-center space-x-2 flex-shrink-0">
                <Checkbox
                  id="select-all"
                  checked={selectAll}
                  onCheckedChange={handleSelectAll}
                  className="h-4 w-4 data-[state=checked]:bg-green-600 data-[state=checked]:border-green-600"
                />
                <label htmlFor="select-all" className="text-xs font-medium text-foreground">
                  Select All
                </label>
              </div>
            </div>
          </div>

          {/* Tracks List - Scrollable */}
          <div className="flex-1 min-h-0 overflow-y-auto px-4">
            <div className="space-y-0.5 py-1">
              {safeTracks
                .slice()
                .sort((a, b) => {
                  const dateA = new Date(a.addedAt).getTime();
                  const dateB = new Date(b.addedAt).getTime();
                  return dateB - dateA; // Most recent first
                })
                .map((track) => (
                <div
                  key={track.id}
                  className={cn(
                    "group flex items-center gap-2 p-2 rounded-md transition-all duration-200",
                    selectedTracks.has(track.id)
                      ? "bg-green-50/30 border-l-2 border-l-green-500"
                      : "border-l-2 border-l-transparent hover:bg-muted/20"
                  )}
                >
                  {/* Checkbox - Smaller and better positioned */}
                  <div className="flex-shrink-0 flex items-center justify-center">
                    <Checkbox
                      checked={selectedTracks.has(track.id)}
                      onCheckedChange={(checked) => handleTrackToggle(track.id, checked as boolean)}
                      className="h-3.5 w-3.5 data-[state=checked]:bg-green-600 data-[state=checked]:border-green-600"
                    />
                  </div>
                  
                  {/* Album Cover with better loading and fallback */}
                  <div className="flex-shrink-0 relative">
                    <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-md bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-700 overflow-hidden">
                      <img
                        src={track.imageUrl}
                        alt={`${track.album} cover`}
                        className="w-full h-full object-cover"
                        loading="lazy"
                        onError={(e) => {
                          const target = e.currentTarget as HTMLImageElement;
                          target.style.display = 'none';
                          // Show fallback icon
                          const parent = target.parentElement;
                          if (parent) {
                            parent.innerHTML = `
                              <div class="w-full h-full flex items-center justify-center">
                                <svg class="w-5 h-5 text-gray-400" fill="currentColor" viewBox="0 0 24 24">
                                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                                </svg>
                              </div>
                            `;
                          }
                        }}
                      />
                    </div>
                  </div>
                  
                  {/* Track Info - Better typography and spacing */}
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm text-foreground truncate leading-tight">{track.title}</p>
                    <p className="text-xs text-muted-foreground truncate leading-tight mt-0.5">{track.artist}</p>
                    <p className="text-[10px] text-muted-foreground/80 truncate leading-tight mt-0.5">{track.album}</p>
                  </div>
                  
                  {/* Duration and Added Date - Better styling */}
                  <div className="flex-shrink-0 flex flex-col items-end gap-1">
                    <div className="flex items-center gap-1">
                      <Clock className="h-3 w-3 text-muted-foreground" />
                      <span className="text-[10px] font-medium text-muted-foreground">{formatTime(track.duration)}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-3 w-3 text-muted-foreground" />
                      <span className="text-[10px] font-medium text-muted-foreground">{formatDate(track.addedAt)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Footer - Fixed */}
          <div className="px-4 pt-2 pb-4 flex-shrink-0 bg-background border-t">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <div className="text-xs sm:text-sm text-muted-foreground">
                {selectedTracks.size} of {safeTracks.length} new songs selected
              </div>
              <div className="flex gap-2">
                <Button 
                  variant="outline" 
                  onClick={onClose}
                  className="text-xs sm:text-sm px-3 py-1 sm:px-4 sm:py-2"
                >
                  Cancel
                </Button>
                <Button
                  onClick={handleSync}
                  disabled={isLoading || selectedTracks.size === 0}
                  className="bg-green-600 hover:bg-green-700 text-white text-xs sm:text-sm px-3 py-1 sm:px-4 sm:py-2"
                >
                  {isLoading ? 'Syncing...' : `Add ${selectedTracks.size} New Songs`}
                </Button>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default SpotifySyncPermissionModal;
